import pdfkit
pdfkit.from_file('mytest.html', 'my_output.pdf')
