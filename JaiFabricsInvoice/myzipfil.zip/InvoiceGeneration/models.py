from django.db import models
import django
# Create your models here.


class CustomerModel(models.Model):
    custName = models.CharField(max_length = 40)
    custGST = models.CharField(max_length = 15)
    address1 = models.CharField(max_length = 50)
    address2 = models.CharField(max_length = 70)
    gstType = models.CharField(max_length =10)
    def __str__(self):
        return '{0}:{1}'.format(self.custName ,self.custGST)

import datetime
class PurchaseModel(models.Model):
    invoicedate = models.CharField(max_length = 40,default="")
    sellerName = models.CharField(max_length = 40, default='')
    sellerGST = models.CharField(max_length = 15, default='')
    invoiceNumber = models.CharField(max_length = 15, default='')
    quantity = models.CharField(max_length = 15, default='')
    pricePerUnit = models.CharField(max_length = 8, default='')
    otherCharges = models.CharField(max_length = 10, default='')
    subTotal = models.CharField(max_length = 10, default='')
    gstType = models.CharField(max_length = 10, default='')
    # GST = models.CharField(max_length = 8, default='')
    IGST = models.CharField(max_length = 10, default = '0')
    CGST = models.CharField(max_length = 10, default = '0')
    SGST = models.CharField(max_length = 10, default = '0')

    totalAmount = models.CharField(max_length = 10)
    def __str__(self):
        return self.sellerName


class SaleModel(models.Model):
    invoiceNumber = models.IntegerField()
    invoiceDate = models.CharField(max_length = 10, blank=True)
    custName = models.CharField(max_length = 40)
    custGST = models.CharField(max_length = 15)
    itemName = models.CharField(max_length = 15)
    quantity = models.CharField(max_length = 10)
    pricePerUnit = models.CharField(max_length = 5)
    subtotal = models.CharField(max_length = 10)
    gstType =   models.CharField(max_length = 10)
    IGST = models.CharField(max_length = 10, default = '0')
    CGST = models.CharField(max_length = 10, default = '0')
    SGST = models.CharField(max_length = 10, default = '0')
    total =models.CharField(max_length = 10)
    transportName = models.CharField(max_length = 25, default='')
    def __str__(self):
        return str(self.invoiceNumber)


