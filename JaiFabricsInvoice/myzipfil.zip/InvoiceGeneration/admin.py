from django.contrib import admin
from InvoiceGeneration.models import CustomerModel, PurchaseModel, SaleModel
# Register your models here.
admin.site.register(CustomerModel)
admin.site.register(PurchaseModel)
admin.site.register(SaleModel)

