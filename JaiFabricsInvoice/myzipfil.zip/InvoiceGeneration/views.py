from django.shortcuts import render
from django.views.generic import DetailView, TemplateView, ListView
# Create your views here.

global no
no = 1

global dict
dict = {}

#CHANGE BILL NO HERE
global fromBillNo
fromBillNo='100'
#PURCHASE
global srPurchase
srPurchase = 1
global fromDatePurchase
fromDatePurchase='2020-10-10'


global Date
Date=''
global itemList
global QuantityList
global PriceList
global finalList
itemList = []
QuantityList=[]
PriceList=[]
finalList = []
global custDetails
custDetails = []

global transportDetails
transportDetails = []

global invoiceNumber
invoiceNumber = 1

global GSTType
GSTType = ''
global custAddress1
global custAddress2
custAddress1 = ''
custAddress2 = ''



global TransportName
global LR_NO
TransportName=''
LR_NO=''
global subtotal
global total
global tax

subtotal, tax, total = 1, 1, 1

from InvoiceGeneration.forms import AddPurchaseForm
from InvoiceGeneration.forms import AddCustomerForm
def AddPurchase(request):
    # pass
    if request.method == "POST":
        form = AddPurchaseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('AddPurchase')

    else:
        form = AddPurchaseForm()
    return render(request, 'AddPurchase.html', {'form': form})

def AddCustomer(request):
    if request.method == "POST":
        form = AddCustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('AddCustomer')


    else:
        form = AddCustomerForm()
    return render(request, 'AddCustomer.html', {'form': form})
global isDuplicate
isDuplicate = 0
def FinalBill(request):
    # template_name = "finalBill.html"
    global subtotal
    global total
    global tax
    global itemList
    global QuantityList
    global PriceList
    global finalList
    global invoiceNumber
    global GSTType
    global Date
    global custAddress1
    global custAddress2
    global TransportName
    global LR_NO
    from num2words import num2words
    totalFigure=num2words(total, to = 'currency', lang='en', currency ='INR'  )
    return render(request, 'finalBill.html',{'TransportName': TransportName, 'lrno':LR_NO, 'GSTType':GSTType,'invoiceNumber':invoiceNumber,'finalList' : finalList,
    'subtotal':subtotal ,'total':total, 'tax':tax, 'customerName':custDetails[1],'custGST':custDetails[0], 'totalFigure':totalFigure, 'invoiceDate':Date,'choice': transportDetails[0],'custAddress1':custAddress1,'custAddress2':custAddress2, 'choiceInfo':transportDetails[1]})
from num2words import num2words
class BasePage(TemplateView):
    template_name = "base.html"
from InvoiceGeneration.models import SaleModel
def GenerateBill(request):
    print(dict, "From generate")
    global itemList
    global QuantityList
    global PriceList
    global finalList
    itemList = []
    QuantityList=[]
    PriceList=[]
    finalList = []
    global subtotal
    global total
    global tax
    global GSTType
    global custAddress1
    global custAddress2
    global Date
    for i in range(0, int(len(dict)/3)):
        # print(i)
        itemList.append(dict['Item_{}'.format(i+1)])
        QuantityList.append(dict['Quantity of {}'.format(i+1)])
        PriceList.append(dict['Price Of {}'.format(i+1)])
        print(dict['Item_{}'.format(i+1)])
        finalList.append([itemList[i], QuantityList[i], PriceList[i], float(QuantityList[i])*float(PriceList[i])])
        subtotal = 0
    for i in range(len(finalList)):
        subtotal+=finalList[i][3]
    tax = round(subtotal*1.0/100*5, 2)
    total = subtotal + tax
    total = round(total, 1)
    global isDuplicate
    global TransportName
    # isDuplicate = False
    if(isDuplicate == '0'):
        try:
            if(GSTType == 'IGST'):
                obj = SaleModel(invoiceNumber = invoiceNumber,invoiceDate = Date, custName = custDetails[1], custGST = custDetails[0],
                itemName = itemList[0], quantity = QuantityList[0], pricePerUnit = PriceList[0], subtotal = subtotal,
                gstType = GSTType , IGST = tax,    total =total, transportName=TransportName)
                obj.save()
            else:
                obj = SaleModel(invoiceNumber = invoiceNumber,invoiceDate = Date, custName = custDetails[1], custGST = custDetails[0],
                itemName = itemList[0], quantity = QuantityList[0], pricePerUnit = PriceList[0], subtotal = subtotal,
                gstType = GSTType , CGST = round(float(tax/2), 2), SGST = round(float(tax/2),2),    total =total,  transportName=TransportName)
                obj.save()
        except Exception as e:
            return HttpResponse(e)

    global LR_NO
    from num2words import num2words
    totalFigure=num2words(total, to = 'currency', lang='en', currency ='INR'  )
    # custAddress1, custAddress2 = 1,1
    return render(request, 'bill.html',{'TransportName': TransportName, 'lrno':LR_NO, 'GSTType':GSTType,'invoiceNumber':invoiceNumber,'finalList' : finalList,
    'subtotal':subtotal ,'total':total, 'tax':tax, 'customerName':custDetails[1],'custGST':custDetails[0], 'totalFigure':totalFigure, 'invoiceDate': Date,'choice': transportDetails[0],'custAddress1':custAddress1,'custAddress2':custAddress2, 'choiceInfo':transportDetails[1]})
    print(finalList)
# class GenerateBill(DetailView):
    # template_name = "bill.html"
    # def get_context_data(self, **kwargs):
        # context = super().get_context_data(**kwargs)
        # context['now'] = timezone.now()
        # return context

import datetime
class saleTotal(ListView):
    template_name = 'saleTotal.html'
    context_object_name = 'saleList'
    today = datetime.datetime.today()

    # if today.month == 1:
    #     one_month_ago = today.replace(year=today.year - 1, month=12)
    # else:
    #     extra_days = 0
    #     while True:
    #         try:
    #             one_month_ago = today.replace(month=today.month - 1, day=today.day - extra_days)
    #             break
    #         except ValueError:
    #             extra_days += 1


    queryset = SaleModel.objects.exclude(invoiceNumber__lt=fromBillNo).order_by('invoiceNumber')
from InvoiceGeneration.models import PurchaseModel
class purchaseTotal(ListView):

    template_name = 'purchaseTotal.html'
    context_object_name = 'purchaseList'
    today = datetime.datetime.today()
    global srPurchase
    queryset = PurchaseModel.objects#.order_by('id')


from InvoiceGeneration.forms import saleDetailsForm
def saleDetailForm(request):
    if request.method == "POST":
        form = saleDetailsForm(request.POST)
        if form.is_valid():
            global fromBillNo
            fromBillNo = int(form.cleaned_data['BillNo'])
            # if(form.cleaned_data['pin']==1803):
            # return HttpResponse(fromBillNo)
            return redirect('saleTotal')

        else:
            return render(request, 'saleDetailForm.html', {'form':form})

            # return render(request, 'securityCheck.html', {'SecurityForm':form})

    else:
        form = saleDetailsForm()

        return render(request, 'saleDetailForm.html', {'form':form})



from InvoiceGeneration.forms import SecurityCheck
def SecurityForm(request):
    if request.method == "POST":
        form = SecurityCheck(request.POST)
        if form.is_valid():
            if(form.cleaned_data['pin']==1803):
                    return redirect('Form')
            else:
                return render(request, 'securityCheck.html', {'SecurityForm':form})

        else:
            return render(request, 'securityCheck.html', {'SecurityForm':form})

    else:
        form = SecurityCheck()

        return render(request, 'securityCheck.html', {'SecurityForm':form})


from InvoiceGeneration.forms import BillInfoForm
def BillInfo(request):
    if request.method == "POST":
        form = BillInfoForm(request.POST)
        if form.is_valid():
            print("HI")
            # form.cleaned_data
            print(form.cleaned_data)
            global dict
            dict = form.cleaned_data
            # return render(request, 'CustomerNItems.html', {'CustForm' : CustForm})
            return redirect("GenerateBill")
    else:

    # template_name = "forms.html"
    # if request.method == "POST":
    #     if CustForm.is_valid():
    #         custDetails = CustForm.save()

    # print(custDetails.noOfItems)
        form = BillInfoForm()
        return render(request, "forms.html", {"form":form})

#Gives the number of items in the bill

# class Inputs:
    # def numberOfInputs(inp = 1):
            # return inp




from django.shortcuts import  redirect

from django.http import HttpResponse
from InvoiceGeneration.models import CustomerModel
from InvoiceGeneration.forms import CustForm
def CustomerAndNumberOfItems(request):
    if request.method == "POST":
        form = CustForm(request.POST)
        if form.is_valid():
            global Date
            Date = form.cleaned_data['invoiceDate']
            global no
            global invoiceNumber
            global  isDuplicate
            isDuplicate = form.cleaned_data['isDuplicate']
            # return HttpResponse(isDuplicate)
            invoiceNumber =  form.cleaned_data['invoiceNumber']
            custName =  form.cleaned_data['custName']
            # return HttpResponse("HI")
            custName = str(custName).split(':')
            custGST = custName[1]
            custName = custName[0]
            # return HttpResponse(custGST)
            global GSTType
            try:
                GSTType = CustomerModel.objects.values('gstType').filter(custName=custName)
                # return HttpResponse(GSTType[0]['gstType'], 'hi')
            except Exception as e:
                return HttpResponse(e, 'hi')
            # GSTType = form.cleaned_data['GST_Type']
            GSTType = GSTType[0]['gstType']
            global custAddress1
            global custAddress2
            try:
                custAddress1 = CustomerModel.objects.values('address1').filter(custName=custName)
                custAddress2 =  CustomerModel.objects.values('address2').filter(custName=custName)
                # return HttpResponse(GSTType, 'hi')
            except Exception as e:
                return HttpResponse(e, 'hi')
            # custAddress1 = form.cleaned_data['custAddress1']
            # custAddress2 = form.cleaned_data['custAddress2']
            custAddress1 = custAddress1[0]['address1']
            custAddress2 = custAddress2[0]['address2']
            # for i in custAddress1:
                # return HttpResponse(i)
            # return HttpResponse(custAddress1, custGST)
            global TransportName
            global LR_NO
            TransportName =  form.cleaned_data['TransportName']
            LR_NO =  form.cleaned_data['LR_NO']

            no =  form.cleaned_data['noOfItems']
            if(LR_NO == ''):
                LR_NO = '          ';
            # custGST =  form.cleaned_data['custGST']
            # form.cleaned_data
            global custDetails
            # custName =  form.cleaned_data['custName']
            custDetails = [custGST, custName]
            global transportDetails
            transportDetails = [ form.cleaned_data['SELECTYOURCHOICE'], form.cleaned_data['GSTorVehicleNumber']]
            print(transportDetails)
            if(transportDetails[1] == ''):
                transportDetails[1] =  '                 ';
            if(transportDetails[0]=='1'):
                transportDetails[0]='GST'
            else:
                transportDetails[0]='Vechicle Number'

            print(  form.cleaned_data['noOfItems'])
            # return render(request, 'CustomerNItems.html', {'CustForm' : CustForm})
            return redirect("BillInfo")
        else: #form is not  validity
            return redirect("ErrorPage")
        # global custDetails
        # custDetails = CustForm
        # return form['noOfItems']

    else:
        customerForm = CustForm
        return render(request, 'CustomerNItems.html', {'CustForm' : CustForm})


def giveNo():
    print("Called from form! Returned=", no)
    return no
