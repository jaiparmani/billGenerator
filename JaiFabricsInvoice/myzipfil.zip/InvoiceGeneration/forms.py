from django import forms
import InvoiceGeneration
# from InvoiceGeneration.views import Inputs
class BillInfoForm(forms.Form):

    name = forms.TextInput()
    def __init__(self, *args, **kwargs):
       super().__init__(*args, **kwargs)
       fields = InvoiceGeneration.views.giveNo()
       # for i in range(fields):
           # self.fields['my_field_%i' % i] = forms.CharField(max_length=100)
       # interests = ProfileInterest.objects.filter(
           # profile=self.instance
       # )
       input = InvoiceGeneration.views.giveNo()
       interests = input
       print(interests)
       for i in range((interests)):
           field_name = 'Item_%s' % (i+1,)
           self.fields[field_name] = forms.CharField(required=False)
           price = 'Price Of %s' %(i+1)
           self.fields[price] = forms.CharField(required=False)
           quantity = "Quantity of %s" %(i+1)
           self.fields[quantity] = forms.CharField(required=False)


           try:
               field_name = 'Item_%s' % (i + 1,)
               self.initial[field_name] = ''
           except IndexError:
               self.initial[field_name] = ''
       # create an extra blank field
       # self.fields[field_name] = forms.CharField(required=False)



from InvoiceGeneration.models import CustomerModel, PurchaseModel

class AddCustomerForm(forms.ModelForm):
    class Meta():
        model = CustomerModel
        exclude = []
        CHOICES=[('CGST+SGST','CGST+SGST'), ('IGST', 'IGST')]
        widgets = {
            'gstType': forms.RadioSelect(choices = CHOICES)
        }

import datetime
class CustForm(forms.Form):
    isDuplicate = forms.ChoiceField(label="Is it a duplicate Bill?",widget = forms.RadioSelect, choices = [('1','YES'), ('0','NO')])
    invoiceNumber = forms.IntegerField(label="Inovice Number",required = True)
    invoiceDate = forms.DateField(label="Inovice Date(YYYY-MM-DD)", required = True)
    # custList = list(CustomerModel.objects.all())
    # for i in CustomerModel.objects.all():
        # custList.append(i)
    # custName = forms.CharField()
    custName = forms.ModelChoiceField(label="Customer Name",queryset=CustomerModel.objects.all(),widget=forms.Select)

    noOfItems = forms.IntegerField(label="Enter number of items:")
    # GST_Type=forms.ChoiceField(widget=forms.RadioSelect, choices=[('CGST+SGST','CGST+SGST'), ('IGST', 'IGST')])
    CHOICES = [('1','GST'), ('2','Vehicle Number')]
    SELECTYOURCHOICE=forms.ChoiceField(label="TRANSPORT",widget=forms.RadioSelect, choices=CHOICES)

    GSTorVehicleNumber=forms.CharField(label="Enter GST or vechicle number of transport:",max_length =  20, required = False)
    TransportName = forms.CharField(label="Enter Transport Name:",max_length = 50, required = False)
    LR_NO = forms.CharField(label="Enter LR no.:",required = False)




class saleDetailsForm(forms.Form):
    BillNo=forms.IntegerField(label="BillNo")
class AddPurchaseForm(forms.ModelForm):
    class Meta():
        model = PurchaseModel
        exclude = []
        CHOICES=[('CGST+SGST','CGST+SGST'), ('IGST', 'IGST')]

        widgets = {
            'gstType': forms.RadioSelect(choices = CHOICES)
        }
class SecurityCheck(forms.Form):
    pin = forms.IntegerField()
