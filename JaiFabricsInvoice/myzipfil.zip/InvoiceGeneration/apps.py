from django.apps import AppConfig


class InvoicegenerationConfig(AppConfig):
    name = 'InvoiceGeneration'
